<?php
/*
Title		: INOF
Description	: Inwave Options Framework
Version		: 1.0
Author		: Inwave
Author URI	: http://inwave.vn
License		: GPLv3 - http://www.gnu.org/copyleft/gpl.html
*/