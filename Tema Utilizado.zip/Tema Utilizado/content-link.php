<?php
/**
 * The default template for displaying content audio
 * @package injob
 */
get_template_part('content', 'image');